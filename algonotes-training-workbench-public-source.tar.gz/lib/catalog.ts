import seed from '../content/seed.json';
import reference from '../content/stl-reference.json';
/** One content catalog for the UI, coach tools and diagnostics. */
const catalog = { ...seed, docs: [...seed.docs, ...reference.docs] };
export default catalog;
