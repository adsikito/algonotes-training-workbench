'use client';
import {useEffect,useRef,useState} from 'react';
import type {Entry} from '../lib/domain';
export function ReadingPosition({owner,target,entries,save,jump,tell,location}:any){
 const marker=useRef<HTMLDivElement>(null),[previous,setPrevious]=useState<any>(null),[busy,setBusy]=useState(false);const key='reading-position:'+owner+':'+target.type+':'+target.id;
 const cloud=entries.filter((e:Entry)=>!e.deleted&&e.kind==='reading-state'&&e.data.targetId===target.id&&e.data.targetType===target.type).sort((a:Entry,b:Entry)=>b.updated.localeCompare(a.updated))[0];
 const live=useRef({location,version:target.version});live.current={location,version:target.version};
 useEffect(()=>{try{const saved=JSON.parse(localStorage.getItem(key)||'null');setPrevious(saved||cloud?.data||null);}catch{setPrevious(cloud?.data||null);}const box=marker.current?.closest('.modal-overlay') as HTMLElement|null;if(!box)return;let timer:any=null;
 const write=()=>{try{localStorage.setItem(key,JSON.stringify({scroll:box.scrollTop,location:live.current.location,sourceVersion:live.current.version,at:new Date().toISOString()}));}catch{}};
 const scroll=()=>{clearTimeout(timer);timer=setTimeout(write,700);};box.addEventListener('scroll',scroll);return()=>{clearTimeout(timer);write();box.removeEventListener('scroll',scroll);};},[key]);
 return <div className="reading-position-control" ref={marker}>{previous&&<button className="button small" onClick={()=>{if(previous.sourceVersion!=null&&target.version!=null&&previous.sourceVersion!==target.version)return tell('来源版本已变化，请先核对摘录；旧位置仍保留');jump?.(previous.location||{});const box=marker.current?.closest('.modal-overlay') as HTMLElement|null;if(box&&typeof previous.scroll==='number')box.scrollTop=previous.scroll;}}>继续上次阅读位置</button>}<button className="button small" disabled={busy} onClick={async()=>{setBusy(true);try{const box=marker.current?.closest('.modal-overlay') as HTMLElement|null;await save('reading-state',{title:target.title,targetId:target.id,targetType:target.type,sourceVersion:target.version??null,location,scroll:box?.scrollTop||0,at:new Date().toISOString()},cloud);tell('阅读位置已保存到云端，没有改变掌握或完成状态');}catch(e:any){tell(e.message);}finally{setBusy(false);}}}>同步阅读位置</button><span className="mini">滚动位置自动保存在本机；跨设备使用“同步阅读位置”。</span></div>;
}
